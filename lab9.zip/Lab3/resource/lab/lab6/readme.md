Beyond the lab requested, I also updated my personal website by adding a menu bar with jquery animation to show my resource list. 

Note that the back button cannot be used in the zip file since there is no file in the path

link: 
https://afsws.rpi.edu/AFS/home/32/wuk9/public_html/iit/