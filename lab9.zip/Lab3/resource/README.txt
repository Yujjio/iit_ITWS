Since I have no idea what can I put in my index page, I just make it simply adding a elaborate background with a title and hyperlink, which connects to my real main page taht contains every lab assignment. I would add a hidden list for all of my resources in this lab folder on my index page's left side after I learned more about Javascript and Jquery, but now there's only a title and an arrow. 

Kerui Wu
Lab3