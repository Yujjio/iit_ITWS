pagelink: https://afsws.rpi.edu/AFS/home/32/wuk9/public_html/iit/

Lab5's file folder's path is: lab3/resource/lab/lab5