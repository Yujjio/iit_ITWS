More than the given example, I added my own photo on the left side of the profile part. I also created some hyperlinks for my address and RPI websites.

Kerui Wu
Lab2
