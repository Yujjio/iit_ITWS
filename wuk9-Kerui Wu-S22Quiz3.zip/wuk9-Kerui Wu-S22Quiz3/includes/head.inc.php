 
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <script type="text/javascript" src="resources/jquery-1.4.3.min.js"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="resources/iit.js"></script>   
    <link href="resources/iit.css" rel="stylesheet" type="text/css"/>
  </head>
  <body>
    <div id="header">
