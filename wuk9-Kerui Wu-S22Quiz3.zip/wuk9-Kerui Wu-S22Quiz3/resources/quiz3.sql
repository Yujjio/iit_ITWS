
-- Place your SQL Commands to create your table and insert data here